import de.tu_berlin.kbs.reflect.InvokeThis;

public class Test {
	
	public static int add(int a, int b) {
		return a + b;
	}
	
	public static int multiply(int a, int b) {
		return a * b;
	}
}