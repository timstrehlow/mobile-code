===================================
Middleware Concepts Assignment 5
How to use it!
===================================

Group members:
Name:Patrick Marschallek Matrikelnummer:352291 
Name: Tim Strehlow Matrikelnummer: 316594
Name: Vincent Schwarzer Matrikelnummer: 352293

Requirements:
JRE 1.6 or higher.

Documentation:
compileAndRun.sh : Use this script to compile all sources and run the server and client. 

The SocketClient's main method will start four client instances, each handing over one of the provided example class files to the server (Echo.class, Annotated.class, HelloWorld.class). Additionally one simple source code file (Test.java) will be sent to the server, containing two methods add(int a, int b) and multiply(int a, int b).

===================================
Functionality has been tested using OS Ubuntu 12.10 and OSX
===================================
